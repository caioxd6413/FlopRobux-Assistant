# FlopRobux Assistant — versão inicial 0.1.0

Aplicativo Android nativo (Kotlin) com WebView do FlopRobux e painel integrado de sugestões. Lê texto visível da página via MutationObserver e envia o texto ao backend de IA configurado pelo usuário. Não envia palpites e não captura senha/cookies.

## Requisitos
- Android Studio recente (AGP 8.7.3; compileSdk 35)
- Hospedagem HTTPS para o backend
- Chave da API OpenAI configurada somente no servidor

## Backend
```bash
cd backend
npm install
export OPENAI_API_KEY='sua-chave'
export OPENAI_MODEL='gpt-4o-mini'
npm start
```
Hospede atrás de HTTPS e configure no app a URL completa `https://seu-dominio/answer`.
**Nunca coloque a chave da API dentro do APK.** Para produção, adicione autenticação própria, limite de requisições e política de privacidade.

## APK
Abra a pasta do projeto no Android Studio, aguarde a sincronização do Gradle e use Build > Build APK(s). O APK de debug será gerado em `app/build/outputs/apk/debug/app-debug.apk`.

## Limitações desta versão
- O leitor genérico observa texto renderizado no DOM; o site pode mudar a estrutura e exigir ajuste dos seletores.
- O conteúdo lido é o texto visível da página, não dados internos ocultos nem dicas ainda não liberadas pelo site.
- O app não envia respostas, não contorna CAPTCHA/Cloudflare e não automatiza ações autenticadas.
- Monitoramento ocorre enquanto o app e a página estão abertos; não é serviço permanente em segundo plano.

## Backend protegido — versão 0.2.0

O backend exige `APP_ACCESS_TOKEN` além da chave da OpenAI. Configure ambas como variáveis de ambiente na hospedagem; nunca coloque a chave da API dentro do APK ou em repositório público.

- `OPENAI_API_KEY`: chave da API OpenAI.
- `APP_ACCESS_TOKEN`: token aleatório longo, igual ao informado no aplicativo.
- `OPENAI_MODEL`: opcional; padrão `gpt-4o-mini`.
- `PORT`: opcional; padrão `3000`.

O endpoint `/answer` exige `Authorization: Bearer <APP_ACCESS_TOKEN>`, limita o texto analisado a 8.000 caracteres e restringe a frequência a 12 chamadas por minuto por IP. `/health` informa se a configuração essencial está presente, sem expor segredos.

### Executar
```bash
cd backend
npm install
cp .env.example .env
# edite .env e preencha os segredos
npm start
```
Hospede com HTTPS antes de conectar o aplicativo. O token do app não substitui controles adicionais de segurança e pode ser extraído de um dispositivo comprometido.

## Publicar o backend no Render (sem colocar segredos no código)
1. Envie esta pasta para um repositório privado no GitHub.
2. No Render, escolha **New > Blueprint** e conecte o repositório. O arquivo `render.yaml` cria o serviço Node.
3. Quando o Render pedir `OPENAI_API_KEY`, informe uma chave criada em https://platform.openai.com/api-keys. A cobrança da API é separada da assinatura ChatGPT.
4. Após a implantação, copie a URL HTTPS do serviço e acrescente `/answer` (ex.: `https://seu-servico.onrender.com/answer`).
5. No painel do app, informe essa URL e o valor de `APP_ACCESS_TOKEN` exibido nas variáveis de ambiente do serviço.

O plano gratuito de hospedagem, quando disponível, pode suspender serviços sem uso e causar demora na primeira chamada. Não publique a chave OpenAI nem o token em repositório, print ou conversa.

## Gerar o APK pelo GitHub Actions
O workflow `.github/workflows/android-apk.yml` compila o APK de debug automaticamente após push para `main`/`master`, ou manualmente em **Actions > Build Android APK > Run workflow**. Depois, baixe o artefato `FlopRobuxAssistant-debug-apk` na execução concluída. O APK é de teste/debug, não assinado para publicação na Play Store.

## Segurança e limitações
- O WebView só permite navegação para `floprobux.gg` e `www.floprobux.gg`, evitando expor a ponte JavaScript do app a páginas externas.
- O botão de leitura manual interpreta corretamente o texto retornado pelo WebView.
- A proteção por token é uma barreira básica; para distribuição ampla, use autenticação por usuário e rate limit persistente no provedor.
- Não foi possível compilar/testar o APK neste ambiente: ele não contém Android SDK/Gradle e não tem acesso à rede para baixar as ferramentas. O workflow acima faz essa compilação em um runner Android/Linux do GitHub.
