package br.com.floprobux.assistant;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.View;
import android.view.Gravity;
import android.webkit.*;
import android.widget.*;
import android.text.InputType;
import org.json.*;
import java.net.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.*;

public class MainActivity extends Activity {
  private WebView web; private TextView status, result, details; private EditText endpoint, appToken;
  private final ExecutorService worker=Executors.newSingleThreadExecutor();
  private String lastText=""; private long lastSent=0;
  private final String dark="#101018", panel="#1B1B28", accent="#A78BFA", muted="#B8B8C8";
  @Override public void onCreate(Bundle b){ super.onCreate(b); build(); }
  private TextView label(String s,int size,int color){ TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(Color.parseColor(color)); return t; }
  private void build(){
    LinearLayout root=new LinearLayout(this); root.setOrientation(1); root.setBackgroundColor(Color.parseColor(dark));
    LinearLayout head=new LinearLayout(this); head.setPadding(16,12,16,8); head.setGravity(Gravity.CENTER_VERTICAL);
    TextView title=label("FlopRobux Assistant",20,"#FFFFFF"); head.addView(title,new LinearLayout.LayoutParams(0,-2,1));
    Button reload=new Button(this); reload.setText("Atualizar"); reload.setOnClickListener(v->web.reload()); head.addView(reload); root.addView(head);
    web=new WebView(this); web.setBackgroundColor(Color.WHITE); WebSettings ws=web.getSettings(); ws.setJavaScriptEnabled(true); ws.setDomStorageEnabled(true); ws.setDatabaseEnabled(true); ws.setMediaPlaybackRequiresUserGesture(true);
    web.setWebViewClient(new WebViewClient(){
      private boolean trusted(String url){ try { String host=new URL(url).getHost(); return host.equals("floprobux.gg") || host.equals("www.floprobux.gg"); } catch(Exception e){ return false; } }
      @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request){
        String url=request.getUrl().toString();
        if(trusted(url)) return false;
        status.setText("Navegação externa bloqueada por segurança.");
        return true;
      }
      @Override public void onPageFinished(WebView v,String url){
        if(trusted(url)){ status.setText("Página carregada • faça login normalmente, se necessário"); injectReader(); }
        else status.setText("Site não autorizado.");
      }
    });
    root.addView(web,new LinearLayout.LayoutParams(-1,0,0.58f));
    LinearLayout p=new LinearLayout(this); p.setOrientation(1); p.setPadding(16,12,16,12); p.setBackgroundColor(Color.parseColor(panel));
    status=label("Abrindo FlopRobux…",12,muted); p.addView(status);
    TextView h=label("Sugestões da IA",18,"#FFFFFF"); h.setPadding(0,8,0,4); p.addView(h);
    result=label("As sugestões aparecerão quando o chat tiver dicas suficientes.",17,"#FFFFFF"); p.addView(result);
    details=label("O aplicativo apenas lê o texto visível e sugere respostas. Ele não envia palpites.",12,muted); details.setPadding(0,6,0,8); p.addView(details);
    endpoint=new EditText(this); endpoint.setSingleLine(true); endpoint.setText("https://SEU-SERVIDOR/answer"); endpoint.setTextColor(Color.WHITE); endpoint.setHintTextColor(Color.GRAY); endpoint.setHint("URL do serviço de IA"); endpoint.setTextSize(12); endpoint.setInputType(InputType.TYPE_TEXT_VARIATION_URI); p.addView(endpoint);
    appToken=new EditText(this); appToken.setSingleLine(true); appToken.setTextColor(Color.WHITE); appToken.setHintTextColor(Color.GRAY); appToken.setHint("Token de acesso do aplicativo"); appToken.setTextSize(12); appToken.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD); p.addView(appToken);
    Button analyze=new Button(this); analyze.setText("Analisar texto visível agora"); analyze.setOnClickListener(v->readNow()); p.addView(analyze);
    root.addView(p,new LinearLayout.LayoutParams(-1,0,0.42f)); setContentView(root);
    web.addJavascriptInterface(new ReaderBridge(),"FlopReader"); web.loadUrl("https://floprobux.gg/evento");
  }
  private class ReaderBridge { @JavascriptInterface public void onText(String text){ if(text==null||text.trim().length()<25)return; runOnUiThread(()->{status.setText("Chat/página monitorados • texto atualizado");}); if(text.equals(lastText)||System.currentTimeMillis()-lastSent<8000)return; lastText=text; lastSent=System.currentTimeMillis(); askAI(text); } }
  private void injectReader(){ String js="(function(){if(window.__flopReaderStarted)return;window.__flopReaderStarted=true;function send(){var t=(document.body&&document.body.innerText||'').slice(-10000);if(window.FlopReader)window.FlopReader.onText(t)};send();new MutationObserver(function(){send()}).observe(document.body,{subtree:true,childList:true,characterData:true});})();"; web.evaluateJavascript(js,null); }
  private void readNow(){ web.evaluateJavascript("(document.body&&document.body.innerText||'').slice(-10000)",v->{
    if(v!=null){ try { String s=new JSONArray("["+v+"]").getString(0); if(s.trim().length()>10){lastText=s;askAI(s);} else result.setText("Ainda não há texto suficiente na página."); }
    catch(Exception e){ status.setText("Não foi possível ler o texto da página."); } }
  }); }
  private void askAI(String text){ String url=endpoint.getText().toString().trim(); String tokenValue=appToken.getText().toString().trim(); if(url.contains("SEU-SERVIDOR")||!url.startsWith("https://")){runOnUiThread(()->{result.setText("Configure o endereço HTTPS do servidor de IA.");details.setText("O servidor de exemplo está na pasta backend. Ele precisa ser hospedado e configurado antes de receber análises.");});return;}
    worker.execute(()->{HttpURLConnection c=null;try{ c=(HttpURLConnection)new URL(url).openConnection(); c.setRequestMethod("POST"); c.setConnectTimeout(12000);c.setReadTimeout(20000);c.setDoOutput(true);c.setRequestProperty("Content-Type","application/json; charset=utf-8"); if(!tokenValue.isEmpty()) c.setRequestProperty("Authorization","Bearer "+tokenValue); JSONObject o=new JSONObject();o.put("pageText",text);try(OutputStream os=c.getOutputStream()){os.write(o.toString().getBytes(StandardCharsets.UTF_8));} int code=c.getResponseCode(); InputStream is=code<400?c.getInputStream():c.getErrorStream(); ByteArrayOutputStream b=new ByteArrayOutputStream();byte[] buf=new byte[4096];int n;while((n=is.read(buf))>0)b.write(buf,0,n);JSONObject r=new JSONObject(b.toString("UTF-8"));String answer=r.optString("suggestion","Nenhuma sugestão recebida.");String why=r.optString("reasoning","");runOnUiThread(()->{result.setText(answer);details.setText(why);}); }catch(Exception e){runOnUiThread(()->{status.setText("Não foi possível consultar a IA: "+e.getMessage());});}finally{if(c!=null)c.disconnect();}});
  }
  @Override public void onBackPressed(){if(web!=null&&web.canGoBack())web.goBack();else super.onBackPressed();}
  @Override protected void onDestroy(){super.onDestroy();worker.shutdownNow();if(web!=null)web.destroy();}
}
